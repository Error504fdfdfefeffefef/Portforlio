	var $Video12 = $('.Video12');

$Video12.on('mouseenter', function () {
 $Video12.get(0).play();
});

$Video12.on('mouseout', function () {
 $Video12.get(0).pause();
});







	$(window).load(function () {
    $(".TIllustration").click(function(){
       $('.HIllustration').show();
    });
    $('.HIllustration').click(function(){
        $('.HIllustration').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.HIllustration').hide();
    });
});



	$(window).load(function () {
    $(".TPhotoshop").click(function(){
       $('.HPhotoshop').show();
    });
    $('.HPhotoshop').click(function(){
        $('.HPhotoshop').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.HPhotoshop').hide();
    });
});



	$(window).load(function () {
    $(".TAdreamIcon").click(function(){
       $('.HAdream').show();
    });
    $('.HAdream').click(function(){
        $('.HAdream').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.HAdream').hide();
    });
});


	$(window).load(function () {
    $(".TPpro").click(function(){
       $('.HPpro').show();
    });
    $('.HPpro').click(function(){
        $('.HPpro').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.HPpro').hide();
    });
});



	$(window).load(function () {
    $(".TFirewrok").click(function(){
       $('.HFirewrok').show();
    });
    $('.HFirewrok').click(function(){
        $('.HFirewrok').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.HFirewrok').hide();
    });
});


	$(window).load(function () {
    $(".TAfter").click(function(){
       $('.HAfter').show();
    });
    $('.HAfter').click(function(){
        $('.HAfter').hide();
    });
    $('.popupCloseButton').click(function(){
        $('.HAfter').hide();
    });
});


$(window).load(function () {
	$(".THtml").click(function(){
		 $('.HHtml').show();
	});
	$('.HHtml').click(function(){
			$('.HHtml').hide();
	});
	$('.popupCloseButton').click(function(){
			$('.HHtml').hide();
	});
});

$(window).load(function () {
	$(".TJava").click(function(){
		 $('.HJava').show();
	});
	$('.HJava').click(function(){
			$('.HHJava').hide();
	});
	$('.popupCloseButton').click(function(){
			$('.HJava').hide();
	});
});
